var ball;
var vermelho, azul, amarelo, verde;


function setup() {
  createCanvas(450, 400);
   
  ball = createSprite(20,20,50,50);
  ball.shapeColor = "black";
  ball.velocityX = 10;
  ball.velocityY = 7;
  
  vermelho = createSprite(35,400,150,100);
  vermelho.shapeColor = "red";
  
  azul = createSprite(170,400,120,100);
  azul.shapeColor = "blue";
  
  amarelo = createSprite(290,400,120,100);
  amarelo.shapeColor = "yellow";
  
  verde = createSprite(410,400,120,100);
  verde.shapeColor = "green";
  
}

function draw() {
background(220);
  edges= createEdgeSprites();
  
  
drawSprites();
   edges= createEdgeSprites();
   ball .bounceOff(edges);
  if(verde.isTouching(ball)){
     ball.shapeColor ="green";
    }
  if(vermelho.isTouching(ball)){
     ball.shapeColor ="red";
    }
  if(amarelo.isTouching(ball)){
     ball.shapeColor ="yellow";
}
  if(azul.isTouching(ball)){
     ball.shapeColor ="blue";
  }
}